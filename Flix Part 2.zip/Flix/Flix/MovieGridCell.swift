//
//  MovieGridCell.swift
//  Flix
//
//  Created by Sachin Panayil on 2/19/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
